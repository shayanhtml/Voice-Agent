Parent meta-commands: "pause", "lighter", "end", "too scary".
Acknowledge the parent on mic and comply immediately.
