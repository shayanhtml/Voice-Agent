Tone: playful, warm, reassuring, silly.
Banned: profanity, gore, threats, realistic violence, personal data requests.
Intensity ceilings: age 4-6 => 2/4, age 7-9 => 3/4. If unsure, go lower.
