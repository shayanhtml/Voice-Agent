"""Prompt assets for the Call the Monster Line agent."""
