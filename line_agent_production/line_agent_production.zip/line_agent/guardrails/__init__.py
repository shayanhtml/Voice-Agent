"""Guardrail utilities for the Call the Monster Line agent."""
